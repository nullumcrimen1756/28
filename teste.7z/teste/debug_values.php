<?php
require_once 'config.php';
session_start();

echo "<h2>Debug Nilai Database vs Session</h2>";

// 1. Cek nilai langsung dari database
echo "<h3>1. Nilai Langsung dari Database:</h3>";
$sql = "SELECT 
    t.jumlah, 
    t.uraian, 
    s.kode_subkategori, 
    s.nama_subkategori,
    DATE_FORMAT(t.tanggal, '%M %Y') as bulan_format
FROM transaksi t
LEFT JOIN subkategori s ON t.id_subkategori = s.id_subkategori
WHERE t.jumlah > 0
ORDER BY t.jumlah DESC
LIMIT 10";

$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Jumlah (DB)</th><th>Type</th><th>Uraian</th><th>Kode Sub</th><th>Bulan</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['jumlah'] . "</td>";
        echo "<td>" . gettype($row['jumlah']) . "</td>";
        echo "<td>" . htmlspecialchars($row['uraian']) . "</td>";
        echo "<td>" . htmlspecialchars($row['kode_subkategori'] ?? 'NULL') . "</td>";
        echo "<td>" . htmlspecialchars($row['bulan_format']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Tidak ada data di database.";
}

// 2. Cek nilai dari session Sheet 3
echo "<h3>2. Nilai dari Session Sheet 3:</h3>";
if (isset($_SESSION['sheet3_report']) && isset($_SESSION['sheet3_report']['total_kas'])) {
    $total_kas = $_SESSION['sheet3_report']['total_kas'];
    echo "<p>Jumlah keys di total_kas: " . count($total_kas) . "</p>";
    
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Key</th><th>Nilai (Session)</th><th>Type</th></tr>";
    
    $count = 0;
    foreach ($total_kas as $key => $value) {
        if ($count >= 10) break; // Hanya tampilkan 10 pertama
        echo "<tr>";
        echo "<td>" . htmlspecialchars($key) . "</td>";
        echo "<td>" . $value . "</td>";
        echo "<td>" . gettype($value) . "</td>";
        echo "</tr>";
        $count++;
    }
    echo "</table>";
} else {
    echo "Session sheet3_report tidak ada atau kosong.";
}

// 3. Generate ulang dan bandingkan
echo "<h3>3. Generate Ulang Sheet 3 Report:</h3>";
require_once 'functions.php';

// Hapus session lama
unset($_SESSION['sheet3_report']);

// Generate ulang
generateSheet3Report();

if (isset($_SESSION['sheet3_report']) && isset($_SESSION['sheet3_report']['total_kas'])) {
    $new_total_kas = $_SESSION['sheet3_report']['total_kas'];
    echo "<p>Jumlah keys di total_kas (baru): " . count($new_total_kas) . "</p>";
    
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Key</th><th>Nilai (Baru)</th><th>Type</th></tr>";
    
    $count = 0;
    foreach ($new_total_kas as $key => $value) {
        if ($count >= 10) break;
        echo "<tr>";
        echo "<td>" . htmlspecialchars($key) . "</td>";
        echo "<td>" . $value . "</td>";
        echo "<td>" . gettype($value) . "</td>";
        echo "</tr>";
        $count++;
    }
    echo "</table>";
} else {
    echo "Gagal generate sheet3_report baru.";
}

// 4. Cek error log
echo "<h3>4. Cek Error Log (jika ada):</h3>";
$error_log_path = ini_get('error_log');
if ($error_log_path && file_exists($error_log_path)) {
    $log_content = file_get_contents($error_log_path);
    $debug_lines = array_filter(explode("\n", $log_content), function($line) {
        return strpos($line, 'DEBUG Sheet3') !== false;
    });
    
    if (!empty($debug_lines)) {
        echo "<pre>";
        foreach (array_slice($debug_lines, -10) as $line) { // 10 terakhir
            echo htmlspecialchars($line) . "\n";
        }
        echo "</pre>";
    } else {
        echo "Tidak ada debug log ditemukan.";
    }
} else {
    echo "Error log tidak ditemukan di: " . ($error_log_path ?: 'tidak diset');
}

echo "<h3>5. Test Format Function:</h3>";
function formatRupiahExport($number) {
    return number_format($number, 0, ',', '.');
}

$test_values = [250000, 750000, 450000, 550000];
echo "<table border='1' style='border-collapse: collapse;'>";
echo "<tr><th>Input</th><th>Formatted</th></tr>";
foreach ($test_values as $val) {
    echo "<tr><td>$val</td><td>" . formatRupiahExport($val) . "</td></tr>";
}
echo "</table>";
?>
