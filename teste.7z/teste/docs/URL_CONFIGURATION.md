# URL Configuration Guide

## Overview
Sistem ini menggunakan konfigurasi URL terpusat melalui `config.php` dan helper functions di `includes/url_helper.php` untuk memastikan semua link dan URL mengacu pada pengaturan yang sama.

## Base URL Configuration

### Automatic Detection (Default)
```php
// Di config.php - Base URL terdeteksi otomatis
define('BASE_URL', getBaseUrl());
```

### Manual Configuration
Jika ingin mengatur base URL secara manual, uncomment dan edit baris berikut di `config.php`:

```php
// Untuk localhost
define('BASE_URL', 'http://localhost/teste');

// Untuk production
define('BASE_URL', 'https://yourdomain.com/gereja');
```

## Helper Functions

### Basic URL Functions

#### `url($path = '')`
Generate URL lengkap dari path relatif
```php
echo url('dashboard.php');           // http://localhost/teste/dashboard.php
echo url('admin/users.php');         // http://localhost/teste/admin/users.php
echo url();                          // http://localhost/teste/
```

#### `asset($path = '')`
Generate URL untuk asset (CSS, JS, images)
```php
echo asset('css/style.css');         // http://localhost/teste/css/style.css
echo asset('js/app.js');             // http://localhost/teste/js/app.js
```

#### `redirect($path = '', $code = 302)`
Redirect ke URL tertentu
```php
redirect('dashboard.php');           // Redirect ke dashboard
redirect('login.php', 301);          // Redirect permanent
```

### Advanced URL Functions

#### `page_url($page, $params = [])`
Generate URL dengan parameter GET
```php
echo page_url('index.php', ['action' => 'report']);
// http://localhost/teste/index.php?action=report

echo page_url('search.php', ['q' => 'test', 'page' => 2]);
// http://localhost/teste/search.php?q=test&page=2
```

#### `export_url($export_file, $filters = [])`
Generate URL untuk export dengan parameter filter
```php
$filters = [
    'jurnal_filter' => 1,
    'tahun_filter' => 2025,
    'search' => 'keyword'
];
echo export_url('sheet2_export.php', $filters);
// http://localhost/teste/sheet2_export.php?jurnal_filter=1&tahun_filter=2025&search=keyword
```

#### `view_url($view, $params = [])`
Generate URL untuk view
```php
echo view_url('sheet2_report', ['filter' => 'active']);
// http://localhost/teste/views/sheet2_report.php?filter=active
```

### Navigation Helper Functions

#### `active_class($path, $class = 'active')`
Generate class 'active' jika halaman saat ini
```php
<a href="<?= url('dashboard.php') ?>" class="<?= active_class('dashboard.php') ?>">
    Dashboard
</a>
```

#### `is_current_page($path)`
Check apakah URL saat ini sama dengan path yang diberikan
```php
if (is_current_page('dashboard.php')) {
    echo "You are on dashboard";
}
```

### Form Helper Functions

#### `form_action($action = '')`
Generate URL untuk form action
```php
<form action="<?= form_action('process.php') ?>" method="post">
    <!-- form content -->
</form>
```

#### `ajax_url($handler, $params = [])`
Generate URL untuk AJAX request
```php
echo ajax_url('get_data.php', ['type' => 'json']);
// http://localhost/teste/ajax/get_data.php?type=json
```

## Usage Examples

### Navigation Menu
```php
<nav>
    <a href="<?= url('dashboard.php') ?>" class="<?= active_class('dashboard.php') ?>">
        Dashboard
    </a>
    <a href="<?= page_url('index.php', ['action' => 'report']) ?>">
        Reports
    </a>
</nav>
```

### Export Buttons
```php
<?php 
$export_filters = [
    'jurnal_filter' => $selected_jurnal_filter,
    'tahun_filter' => $selected_tahun_filter,
    'search' => $search_keyword
];
?>
<a href="<?= export_url('sheet2_export.php', $export_filters) ?>" class="btn btn-success">
    Export Excel
</a>
```

### Form Actions
```php
<form action="<?= form_action('login.php') ?>" method="post">
    <input type="text" name="username">
    <input type="password" name="password">
    <button type="submit">Login</button>
</form>
```

### AJAX Calls
```javascript
$.ajax({
    url: '<?= ajax_url("get_categories.php") ?>',
    method: 'GET',
    success: function(data) {
        // handle response
    }
});
```

## File Structure

```
/
├── config.php                 # Base URL configuration
├── includes/
│   └── url_helper.php         # URL helper functions
├── views/
│   ├── header.php            # Updated with URL helpers
│   ├── sheet2_report.php     # Updated with URL helpers
│   └── sheet3_report.php     # Updated with URL helpers
├── dashboard.php             # Updated with URL helpers
├── login.php                 # Updated with URL helpers
├── index.php                 # Updated with URL helpers
└── docs/
    └── URL_CONFIGURATION.md  # This documentation
```

## Migration Guide

### Before (Hardcoded URLs)
```php
<a href="dashboard.php">Dashboard</a>
<a href="sheet2_export.php?filter=1">Export</a>
<form action="login.php" method="post">
```

### After (Using URL Helpers)
```php
<a href="<?= url('dashboard.php') ?>">Dashboard</a>
<a href="<?= export_url('sheet2_export.php', ['filter' => 1]) ?>">Export</a>
<form action="<?= form_action('login.php') ?>" method="post">
```

## Benefits

1. **Centralized Configuration**: Semua URL mengacu pada satu konfigurasi
2. **Easy Deployment**: Ganti base URL di satu tempat untuk deploy ke server berbeda
3. **Consistent URLs**: Semua link menggunakan format yang sama
4. **Parameter Handling**: Helper functions menangani parameter GET dengan mudah
5. **Active State Management**: Otomatis mendeteksi halaman aktif untuk navigation
6. **SEO Friendly**: URL yang konsisten dan clean

## Testing

### Automated Testing
Gunakan file `test_url_config.php` untuk testing semua URL helper functions:

```bash
# Akses melalui browser
http://localhost/teste/test_url_config.php
```

File ini akan menampilkan:
- Base URL configuration
- Test semua helper functions
- Link testing untuk navigasi
- File path validation

### Manual Testing Checklist
- [ ] Semua link di navigation bekerja
- [ ] Form submission redirect dengan benar
- [ ] Export buttons menghasilkan URL yang benar
- [ ] Asset loading (CSS/JS) berfungsi
- [ ] Redirect functions bekerja

## Troubleshooting

### Base URL Detection Issues
Jika auto-detection tidak bekerja dengan baik, gunakan manual configuration:
```php
// Uncomment dan edit di config.php
define('BASE_URL', 'http://your-actual-domain.com/path-to-app');
```

### Missing Helper Functions
Pastikan `includes/url_helper.php` di-include di setiap file yang menggunakan helper functions:
```php
require_once 'includes/url_helper.php';
```

### URL Not Working
Check apakah BASE_URL sudah terdefinisi:
```php
if (!defined('BASE_URL')) {
    echo "BASE_URL not defined!";
}
echo "Current BASE_URL: " . BASE_URL;
```

### File Path Issues
Gunakan helper functions untuk file paths:
```php
// Gunakan base_path() untuk include files
require_once base_path('config.php');

// Gunakan views_path() untuk view files
include views_path('header.php');
```
