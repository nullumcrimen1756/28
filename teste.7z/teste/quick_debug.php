<?php
require_once 'config.php';
require_once 'functions.php';
session_start();

echo "<h2>QUICK DEBUG - Nilai Hilang Ribuan</h2>";

// 1. Cek database langsung
echo "<h3>1. Database Langsung (5 nilai tertinggi):</h3>";
$sql = "SELECT jumlah, uraian FROM transaksi WHERE jumlah > 0 ORDER BY jumlah DESC LIMIT 5";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $jumlah = $row['jumlah'];
        echo "<p><strong>DB:</strong> $jumlah | <strong>Type:</strong> " . gettype($jumlah) . " | <strong>Float:</strong> " . (float)$jumlah . " | <strong>Formatted:</strong> " . number_format($jumlah, 0, ',', '.') . " | <strong>Uraian:</strong> " . htmlspecialchars($row['uraian']) . "</p>";
    }
} else {
    echo "<p>Tidak ada data di database</p>";
}

// 2. Generate Sheet 3 dan cek session
echo "<h3>2. Generate Sheet 3 Report:</h3>";
generateSheet3Report();

if (isset($_SESSION['sheet3_report']['total_kas'])) {
    $total_kas = $_SESSION['sheet3_report']['total_kas'];
    echo "<p>Jumlah keys di total_kas: " . count($total_kas) . "</p>";
    
    $count = 0;
    foreach ($total_kas as $key => $value) {
        if ($count >= 5) break;
        echo "<p><strong>Session:</strong> $key = $value | <strong>Type:</strong> " . gettype($value) . " | <strong>Formatted:</strong> " . number_format($value, 0, ',', '.') . "</p>";
        $count++;
    }
} else {
    echo "<p>Session total_kas tidak ada</p>";
}

// 3. Test format function
echo "<h3>3. Test Format Function:</h3>";
function formatRupiahExport($number) {
    return number_format($number, 0, ',', '.');
}

$test_values = [250000, 750000, 450000, 550000, 250, 750, 450, 550];
foreach ($test_values as $val) {
    echo "<p>Input: $val → Formatted: " . formatRupiahExport($val) . "</p>";
}

// 4. Cek apakah ada masalah di konversi float
echo "<h3>4. Test Konversi Float:</h3>";
$test_strings = ['250000', '750000', '250000.00', '750000.00'];
foreach ($test_strings as $str) {
    $float_val = (float)$str;
    echo "<p>String: '$str' → Float: $float_val → Formatted: " . number_format($float_val, 0, ',', '.') . "</p>";
}

// 5. Simulasi proses yang sama seperti di functions.php
echo "<h3>5. Simulasi Proses generateSheet3Report:</h3>";
$sql = "SELECT jumlah, uraian FROM transaksi WHERE jumlah > 0 LIMIT 3";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $original = $row['jumlah'];
        $kas = (float)$row['jumlah']; // Sama seperti di functions.php line 357
        
        echo "<p>";
        echo "<strong>Original:</strong> $original (" . gettype($original) . ") → ";
        echo "<strong>Float:</strong> $kas (" . gettype($kas) . ") → ";
        echo "<strong>Formatted:</strong> " . number_format($kas, 0, ',', '.') . " | ";
        echo "<strong>Uraian:</strong> " . htmlspecialchars($row['uraian']);
        echo "</p>";
    }
}

echo "<hr>";
echo "<p><strong>Kesimpulan:</strong> Jika nilai di database benar (250000) tapi di export menjadi (250), maka masalahnya ada di:</p>";
echo "<ul>";
echo "<li>1. Proses konversi di generateSheet3Report()</li>";
echo "<li>2. Proses penyimpanan ke session</li>";
echo "<li>3. Proses pembacaan dari session di export</li>";
echo "<li>4. Format function di export</li>";
echo "</ul>";
?>
