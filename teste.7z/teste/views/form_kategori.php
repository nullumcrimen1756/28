<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
        }
        
        .card-form {
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            border: none;
        }
        
        .form-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        
        .form-label {
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .btn-submit {
            background-color: var(--secondary-color);
            border: none;
        }
        
        .btn-submit:hover {
            background-color: #2980b9;
        }
        .text-end {
            text-align: right !important;
        }
        
        /* Tambahan untuk form validation */
        .form-control:invalid {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 0.25rem rgba(231, 76, 60, 0.25);
        }
        
        .form-control:valid {
            border-color: #28a745;
            border-width: 2px;
            box-shadow: 0 0 0 0.25rem rgba(40, 167, 69, 0.25);
        }
        
        .form-text {
            font-size: 0.875rem;
            color: #6c757d;
            line-height: 1.4;
        }
        
        .form-text i {
            color: var(--secondary-color);
        }
        
        .form-text strong {
            color: var(--primary-color);
        }
        
        .form-text .text-muted {
            color: #6c757d !important;
        }
        
        .form-text .text-success {
            color: #28a745 !important;
        }
        
        /* Styling untuk input yang sedang difokuskan */
        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        /* Styling untuk placeholder */
        .form-control::placeholder {
            color: #adb5bd;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card card-form">
                    <div class="card-header form-header">
                        <h4 class="mb-0"><i class="bi bi-tag me-2"></i>Form Tambah Kategori</h4>
                    </div>
                    
                    <div class="card-body">
                        <?php if (isset($_SESSION['error'])): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <form action="admin_kategori.php?action=save_kategori<?php echo $selected_jurnal_id ? '&id_jurnal='.$selected_jurnal_id : ''; ?>" method="post">
                        <div class="mb-3">
                            <label for="id_jurnal" class="form-label">Jurnal</label>
                            <select id="id_jurnal" name="id_jurnal" class="form-select" required>
                                <option value="" selected disabled>Pilih Jurnal</option>
                                <?php foreach ($jurnals as $jurnal): ?>
                                    <option value="<?php echo $jurnal['id_jurnal']; ?>"
                                        <?php echo ($selected_jurnal_id == $jurnal['id_jurnal']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($jurnal['nama_jurnal']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                            
                            <div class="mb-3">
                                <label for="kode_kategori" class="form-label">
                                    Kode Kategori <span class="text-danger">*</span>
                                </label>
                                <input type="text" 
                                       class="form-control" 
                                       id="kode_kategori" 
                                       name="kode_kategori" 
                                       placeholder="Contoh: 100, 200, 300" 
                                       pattern="[0-9]{3}" 
                                       title="Kode harus 3 digit angka"
                                       maxlength="3"
                                       required>
                                <div class="form-text">
                                    <i class="bi bi-info-circle me-1"></i>
                                    <strong>Format:</strong> 3 digit angka untuk kategori utama
                                    <br>
                                    <small class="text-muted">
                                        • <strong>100</strong> = Operasional & Administrasi<br>
                                        • <strong>200</strong> = Program Sosial & Pelayanan<br>
                                        • <strong>300</strong> = Pendidikan & Pelatihan<br>
                                        • <strong>400</strong> = Fasilitas & Infrastruktur<br>
                                        • <strong>500</strong> = Lain-lain
                                    </small>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <label for="nama_kategori" class="form-label">Nama Kategori</label>
                                <input type="text" id="nama_kategori" name="nama_kategori" class="form-control" required>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <a href="admin_kategori.php<?php echo isset($_GET['id_jurnal']) ? '?id_jurnal='.$_GET['id_jurnal'] : ''; ?>" 
                                   class="btn btn-outline-secondary me-md-2">
                                    <i class="bi bi-arrow-left me-1"></i> Kembali
                                </a>
                                <button type="submit" class="btn btn-submit text-white">
                                    <i class="bi bi-save me-1"></i> Simpan
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>