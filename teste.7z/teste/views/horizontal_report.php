
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Horizontal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #2c3e50;
        }
        .nav {
            margin-bottom: 20px;
            text-align: center;
        }
        .nav a {
            margin: 0 10px;
            text-decoration: none;
            color: #3498db;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            position: sticky;
            top: 0;
        }
        .category-row {
            background-color: #e6f7ff;
        }
        .subcategory-row {
            background-color: #f9f9f9;
        }
        .group-total {
            background-color: #fffacd;
            font-weight: bold;
        }
        .category-total {
            background-color: #d4edda;
            font-weight: bold;
        }
        .grand-total {
            background-color: #cce5ff;
            font-weight: bold;
        }
        .number {
            text-align: right;
        }
        @media print {
            .nav {
                display: none;
            }
        }
    </style>
</head>
<body>
    <h1>Laporan Pengeluaran Horizontal</h1>
    
    <div class="nav">
        <a href="index.php">Form Input</a>
        <a href="index.php?action=report&type=structured">Laporan Terstruktur</a>
        <a href="index.php?action=report">Laporan Horizontal</a>
    </div>
    
    <!-- Filter Laporan -->
    <div class="card mb-4">
        <div class="card-header">
            <h6 class="mb-0">Filter Laporan</h6>
        </div>
        <div class="card-body">
            <form method="get" action="index.php" class="row g-3 align-items-center">
                <input type="hidden" name="action" value="report">
                <div class="col-md-4">
                    <label for="jurnal_filter" class="form-label">Jurnal:</label>
                    <select name="jurnal_filter" id="jurnal_filter" class="form-select" onchange="this.form.submit()">
                        <option value="">Semua Jurnal</option>
                        <?php 
                        $selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';
                        foreach ($daftar_jurnal as $id => $nama): ?>
                            <option value="<?= $id ?>" <?= ($selected_jurnal_filter == $id) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($nama) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="tahun_filter" class="form-label">Tahun:</label>
                    <select name="tahun_filter" id="tahun_filter" class="form-select" onchange="this.form.submit()">
                        <?php 
                        $selected_tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
                        for ($year = date('Y'); $year >= 2020; $year--): ?>
                            <option value="<?= $year ?>" <?= ($selected_tahun_filter == $year) ? 'selected' : '' ?>>
                                <?= $year ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">&nbsp;</label><br>
                    <a href="index.php?action=report" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-clockwise me-1"></i>Reset
                    </a>
                </div>
            </form>
        </div>
    </div>

    <?php
    // Generate laporan jika belum ada
    if (!isset($_SESSION['horizontal_report']) || empty($_SESSION['horizontal_report'])) {
        generateHorizontalReport();
    }

    if (isset($_SESSION['horizontal_report']) && !empty($_SESSION['horizontal_report'])): 
        $report = $_SESSION['horizontal_report'];
    ?>
        <table>
            <thead>
                <tr>
                    <th>Kategori</th>
                    <th>Kode Subkategori</th>
                    <th>Uraian</th>
                    <?php foreach ($report['bulan'] as $bulan): ?>
                        <th class="number"><?php echo $bulan; ?></th>
                    <?php endforeach; ?>
                    <th class="number">Total</th>
                    <th class="number">Anggaran Pendapatan</th>
                    <th class="number">Selisih</th>
                </tr>
            </thead>
            <tbody>
                <!-- Uang Setoran -->
                <?php 
                $total_setoran = 0;
                $has_setoran = false;
                ?>
                <?php if (isset($report['subkategori'])): ?>
                    <?php foreach ($report['subkategori'] as $key => $sub): ?>
                        <?php if ($sub['kode_kategori'] === 'Uang Setoran'): ?>
                            <?php $has_setoran = true; ?>
                            <tr class="subcategory-row">
                                <td>Uang Setoran</td>
                                <td></td>
                                <td></td>
                                <?php 
                                $sub_total = 0;
                                foreach ($report['bulan'] as $bulan): 
                                    $amount = isset($sub['bulan'][$bulan]) ? $sub['bulan'][$bulan] : 0;
                                    $sub_total += $amount;
                                ?>
                                    <td class="number"><?php echo number_format($amount, 2); ?></td>
                                <?php endforeach; ?>
                                <td class="number"><?php echo number_format($sub_total, 2); ?></td>
                                <td class="number"></td>
                                <td class="number"><?php echo number_format($sub_total, 2); ?></td>
                            </tr>
                            <?php $total_setoran = $sub_total; ?>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
                
                <!-- Kategori dan Subkategori -->
                <?php 
                $current_group = '';
                $last_group = '';
                $group_totals = [];
                ?>
                
                <?php foreach ($report['subkategori'] as $key => $sub): ?>
                    <?php 
                    if ($sub['kode_kategori'] === 'Uang Setoran') continue;
                    
                    $group = substr($sub['kode_kategori'], 0, 3);
                    ?>
                    
                    <?php if ($group !== $current_group): ?>
                        <?php if ($current_group !== ''): ?>
                            <!-- Total Kelompok -->
                            <tr class="group-total">
                                <td>Total Kelompok <?php echo $current_group; ?></td>
                                <td></td>
                                <td></td>
                                <?php 
                                $group_total = 0;
                                foreach ($report['bulan'] as $bulan): 
                                    $amount = isset($report['total_kelompok'][$current_group]['bulan'][$bulan]) ? 
                                        $report['total_kelompok'][$current_group]['bulan'][$bulan] : 0;
                                    $group_total += $amount;
                                ?>
                                    <td class="number"><?php echo number_format($amount, 2); ?></td>
                                <?php endforeach; ?>
                                <td class="number"><?php echo number_format($group_total, 2); ?></td>
                                <td class="number"></td>
                                <td class="number"><?php echo number_format($group_total, 2); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php $current_group = $group; ?>
                    <?php endif; ?>
                    
                    <!-- Subkategori -->
                    <tr class="subcategory-row">
                        <td><?php echo $sub['kode_kategori'] . ' - ' . $sub['nama_kategori']; ?></td>
                        <td><?php echo $sub['kode_subkategori']; ?></td>
                        <td><?php echo $sub['nama_subkategori']; ?></td>
                        <?php 
                        $sub_total = 0;
                        foreach ($report['bulan'] as $bulan): 
                            $amount = isset($sub['bulan'][$bulan]) ? $sub['bulan'][$bulan] : 0;
                            $sub_total += $amount;
                        ?>
                            <td class="number"><?php echo number_format($amount, 2); ?></td>
                        <?php endforeach; ?>
                        <td class="number"><?php echo number_format($sub_total, 2); ?></td>
                        <td class="number">0</td>
                        <td class="number"><?php echo number_format($sub_total, 2); ?></td>
                    </tr>
                    
                    <?php $last_group = $group; ?>
                <?php endforeach; ?>
                
                <!-- Total Kelompok Terakhir -->
                <?php if ($current_group !== ''): ?>
                    <tr class="group-total">
                        <td>Total Kelompok <?php echo $current_group; ?></td>
                        <td></td>
                        <td></td>
                        <?php 
                        $group_total = 0;
                        foreach ($report['bulan'] as $bulan): 
                            $amount = isset($report['total_kelompok'][$current_group]['bulan'][$bulan]) ? 
                                $report['total_kelompok'][$current_group]['bulan'][$bulan] : 0;
                            $group_total += $amount;
                        ?>
                            <td class="number"><?php echo number_format($amount, 2); ?></td>
                        <?php endforeach; ?>
                        <td class="number"><?php echo number_format($group_total, 2); ?></td>
                        <td class="number"></td>
                        <td class="number"><?php echo number_format($group_total, 2); ?></td>
                    </tr>
                <?php endif; ?>
                
                <!-- Total Keseluruhan -->
                <tr class="grand-total">
                    <td>Total Keseluruhan</td>
                    <td></td>
                    <td></td>
                    <?php 
                    $grand_total = 0;
                    foreach ($report['bulan'] as $bulan): 
                        $amount = isset($report['total_keseluruhan'][$bulan]) ? $report['total_keseluruhan'][$bulan] : 0;
                        $grand_total += $amount;
                    ?>
                        <td class="number"><?php echo number_format($amount, 2); ?></td>
                    <?php endforeach; ?>
                    <td class="number"><?php echo number_format($grand_total, 2); ?></td>
                    <td class="number"></td>
                    <td class="number"><?php echo number_format($grand_total, 2); ?></td>
                </tr>
            </tbody>
        </table>
    <?php else: ?>
        <p>Tidak ada data laporan horizontal. Silakan input data terlebih dahulu.</p>
    <?php endif; ?>
</body>
</html>