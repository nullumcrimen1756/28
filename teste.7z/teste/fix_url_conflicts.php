<?php
/**
 * Fix URL Conflicts
 * File untuk mendeteksi dan memperbaiki konflik fungsi URL
 */

echo "<h2>🔧 Fix URL Conflicts</h2>";

// 1. Test loading config.php
echo "<h3>1. Testing config.php</h3>";
try {
    require_once 'config.php';
    echo "<p>✅ config.php loaded successfully</p>";
    echo "<p>BASE_URL: " . (defined('BASE_URL') ? BASE_URL : 'NOT DEFINED') . "</p>";
    
    // Check if URL functions exist after config.php
    $functions_after_config = [];
    $test_functions = ['url', 'asset', 'redirect', 'base_path', 'views_path'];
    foreach ($test_functions as $func) {
        if (function_exists($func)) {
            $functions_after_config[] = $func;
        }
    }
    
    if (!empty($functions_after_config)) {
        echo "<p>⚠️ Functions already defined in config.php: " . implode(', ', $functions_after_config) . "</p>";
    } else {
        echo "<p>✅ No URL functions defined in config.php (good!)</p>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Error loading config.php: " . $e->getMessage() . "</p>";
}

// 2. Test loading url_helper.php
echo "<h3>2. Testing url_helper.php</h3>";
try {
    require_once 'includes/url_helper.php';
    echo "<p>✅ url_helper.php loaded successfully</p>";
    
    // Check all required functions
    $required_functions = [
        'url', 'asset', 'redirect', 'page_url', 'export_url', 'view_url',
        'api_url', 'is_current_page', 'active_class', 'form_action',
        'ajax_url', 'download_url', 'url_with_hash', 'current_url', 'previous_url',
        'base_path', 'views_path', 'include_view', 'file_exists_in_base', 'view_exists'
    ];
    
    $available_functions = [];
    $missing_functions = [];
    
    foreach ($required_functions as $func) {
        if (function_exists($func)) {
            $available_functions[] = $func;
        } else {
            $missing_functions[] = $func;
        }
    }
    
    echo "<p>✅ Available functions (" . count($available_functions) . "): " . implode(', ', $available_functions) . "</p>";
    
    if (!empty($missing_functions)) {
        echo "<p>❌ Missing functions (" . count($missing_functions) . "): " . implode(', ', $missing_functions) . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Error loading url_helper.php: " . $e->getMessage() . "</p>";
}

// 3. Test URL functions
echo "<h3>3. Testing URL Functions</h3>";
if (function_exists('url')) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Function</th><th>Input</th><th>Output</th><th>Status</th></tr>";
    
    // Test url()
    try {
        $test_url = url('dashboard.php');
        echo "<tr><td>url()</td><td>'dashboard.php'</td><td>$test_url</td><td>✅</td></tr>";
    } catch (Exception $e) {
        echo "<tr><td>url()</td><td>'dashboard.php'</td><td>ERROR: " . $e->getMessage() . "</td><td>❌</td></tr>";
    }
    
    // Test asset()
    try {
        $test_asset = asset('css/style.css');
        echo "<tr><td>asset()</td><td>'css/style.css'</td><td>$test_asset</td><td>✅</td></tr>";
    } catch (Exception $e) {
        echo "<tr><td>asset()</td><td>'css/style.css'</td><td>ERROR: " . $e->getMessage() . "</td><td>❌</td></tr>";
    }
    
    // Test page_url()
    try {
        $test_page = page_url('index.php', ['action' => 'report']);
        echo "<tr><td>page_url()</td><td>'index.php', ['action' => 'report']</td><td>$test_page</td><td>✅</td></tr>";
    } catch (Exception $e) {
        echo "<tr><td>page_url()</td><td>'index.php', ['action' => 'report']</td><td>ERROR: " . $e->getMessage() . "</td><td>❌</td></tr>";
    }
    
    // Test export_url()
    try {
        $test_export = export_url('sheet2_export.php', ['filter' => 1]);
        echo "<tr><td>export_url()</td><td>'sheet2_export.php', ['filter' => 1]</td><td>$test_export</td><td>✅</td></tr>";
    } catch (Exception $e) {
        echo "<tr><td>export_url()</td><td>'sheet2_export.php', ['filter' => 1]</td><td>ERROR: " . $e->getMessage() . "</td><td>❌</td></tr>";
    }
    
    echo "</table>";
} else {
    echo "<p>❌ url() function not available</p>";
}

// 4. Test file path functions
echo "<h3>4. Testing File Path Functions</h3>";
if (function_exists('base_path')) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Function</th><th>Input</th><th>Output</th><th>Exists?</th></tr>";
    
    // Test base_path()
    $test_base = base_path();
    echo "<tr><td>base_path()</td><td>''</td><td>$test_base</td><td>" . (is_dir($test_base) ? '✅' : '❌') . "</td></tr>";
    
    $test_config = base_path('config.php');
    echo "<tr><td>base_path()</td><td>'config.php'</td><td>$test_config</td><td>" . (file_exists($test_config) ? '✅' : '❌') . "</td></tr>";
    
    // Test views_path()
    $test_views = views_path();
    echo "<tr><td>views_path()</td><td>''</td><td>$test_views</td><td>" . (is_dir($test_views) ? '✅' : '❌') . "</td></tr>";
    
    $test_header = views_path('header.php');
    echo "<tr><td>views_path()</td><td>'header.php'</td><td>$test_header</td><td>" . (file_exists($test_header) ? '✅' : '❌') . "</td></tr>";
    
    echo "</table>";
} else {
    echo "<p>❌ base_path() function not available</p>";
}

// 5. Recommendations
echo "<h3>5. 🎯 Recommendations</h3>";

if (empty($missing_functions)) {
    echo "<div style='background-color: #d4edda; padding: 15px; border-radius: 5px; border-left: 4px solid #28a745;'>";
    echo "<h4>✅ Configuration is Correct!</h4>";
    echo "<p>All URL helper functions are available and working properly.</p>";
    echo "<ul>";
    echo "<li>BASE_URL is defined: " . (defined('BASE_URL') ? BASE_URL : 'NO') . "</li>";
    echo "<li>All " . count($available_functions) . " functions are available</li>";
    echo "<li>No function conflicts detected</li>";
    echo "</ul>";
    echo "</div>";
} else {
    echo "<div style='background-color: #f8d7da; padding: 15px; border-radius: 5px; border-left: 4px solid #dc3545;'>";
    echo "<h4>❌ Configuration Issues Found</h4>";
    echo "<p>Please fix the following issues:</p>";
    echo "<ul>";
    if (!defined('BASE_URL')) {
        echo "<li>BASE_URL is not defined - check config.php</li>";
    }
    if (!empty($missing_functions)) {
        echo "<li>Missing functions: " . implode(', ', $missing_functions) . "</li>";
        echo "<li>Make sure includes/url_helper.php is included properly</li>";
    }
    echo "</ul>";
    echo "</div>";
}

// 6. Next Steps
echo "<h3>6. 📝 Next Steps</h3>";
echo "<ol>";
echo "<li>If all tests pass, update all files to use URL helpers</li>";
echo "<li>Remove hardcoded URLs from all PHP files</li>";
echo "<li>Test navigation and form submissions</li>";
echo "<li>Deploy to production and test BASE_URL detection</li>";
echo "</ol>";

echo "<hr>";
echo "<p><strong>Generated at:</strong> " . date('Y-m-d H:i:s') . "</p>";
?>
